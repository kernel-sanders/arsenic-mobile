//
//  UINibDeclarations.h
//  UIKit
//
//  Copyright 2005-2008 Apple Inc. All rights reserved.
//

#ifndef IBOutlet
#define IBOutlet
#endif

#ifndef IBAction
#define IBAction void
#endif
